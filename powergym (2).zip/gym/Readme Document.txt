Usernames and passwords

Admin
	Username: admin
	Password: admin	
	Position: trainer

Trainers
	Username: Mia Rodriguez
	Password: password
	Position: trainer

	Username: Alex Johnson
	Password: password
	Position: trainer

Client
	Username: Sara Carmona
	Password: password
	Position: client

	Username: Emma Turner
	Password: password
	Position: client



