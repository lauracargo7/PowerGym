<?php
    function display_Navigation($page){ 
        if($page == 'index') { 
            echo'
            <div class="nav">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="pages/equipment.php">Equipment</a></li>
                    <li><a href="pages/timetable.php">Timetable</a></li>
                    <li><a href="pages/about.php">About us</a></li>
                    <li><a href="pages/contact.php">Contact</a></li>
                    <li><a href="pages/dashboard.php">Dashboard</a></li>
                    <li><a href="index.php?logout=logout">Logout</a></li>
                    ';
                    
                echo'</ul>
            </div>
            
        ';
       
        } else { 
            echo'
            <div class="nav">
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="equipment.php">Equipment</a></li>
                    <li><a href="timetable.php">Timetable</a></li>
                    <li><a href="about.php">About us</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="../index.php?logout=logout">Logout</a></li>
                        ';
                    
                echo'
                </ul>
            </div>
            '; 
            }
    }    

    function dbLink(){
        $db_user = 'mri';
        $db_pass = 'password';
        $db_host = 'localhost';
        $db = 'gymgym';
        try{
            $db = new PDO("mysql:host=$db_host;dbname=$db", $db_user,$db_pass);
        } catch (Exception $e){
        echo 'Unable to access database. ';
        exit;
        }
        error_reporting(0);
        return $db;
        }

        function validateUser($dbConnect, $uname, $pwd, $table){
            $sql = "SELECT * FROM $table";
            foreach ($dbConnect->query($sql) as $row) {
                if ($uname == $row['uname']) {
                    if ($pwd == $row['password']) {
                        $_SESSION['uname' ] = $row['uname'];
                        $_SESSION['password'] = $row['password'];
                        $_SESSION['position'] = $row['position'];
                        $_SESSION['userid'] = $row['id'];
                        $_SESSION['validate' ] = 'validated';
                        return true;
                    }
            return false;
                }
            }   
        }

        function showMem() {
            echo '<pre>';
            echo '<h3>GET Memory</h3>';
            print_r($_GET);
            echo '<h3>POST Memory</h3>';
            print_r($_POST);
            echo '<h3>SESSION Memory</h3>';
            print_r($_SESSION);
            echo '</pre>';
        }     

    function insertuser($dbConnect, $uname, $encrypted_password, $table){
        if($table == "trainers"){ 
            $sql = "INSERT INTO $table (id, uname, password, position) VALUES (NULL, :un, :pwd, :pos)";
            $query = $dbConnect->prepare($sql);
            $query->bindParam(":un", $uname);
            $query->bindParam(":pwd", $encrypted_password);
            $query->bindParam(":pos", $table);
            $result = $query->execute();
            return $result;
        } else {
            $table = 'clients';
            $sql = "INSERT INTO $table (id, uname, password) VALUES (NULL, :un, :pwd)";
            $query = $dbConnect->prepare($sql);
            $query->bindParam(":un", $uname);
            $query->bindParam(":pwd", $encrypted_password);
            $result = $query->execute();
            return $result;
        }
    }

    function insertClass($dbConnect, $classes) {
        $table = 'classes';
        $sql = "INSERT INTO $table(id, uname) VALUES (NULL, :classes)";
        $query = $dbConnect->prepare($sql);
        $query->bindParam(":classes", $classes);
        $result = $query->execute();
        return $result;
    }

    function viewItem($dbConnect, $table) {
        echo '
        <div class="ctaBox">
        <h3>' .ucfirst($table).'</h3><br>';
        $sql = "SELECT * from $table";
        foreach ($dbConnect->query($sql) as $row)
        { 
            $itemid=$row['id'];
            echo $row['uname'];
            echo '<a href="removepage.php?itemid=' .$itemid.'&table='.$table.' ">Remove</a>';
            if($table!="class"){
                echo '<a href="update.php?itemid=' .$itemid. '&table=' .$table.' ">Update</a>';
            }
            echo '<br>';
        }
        echo '</div>';
    }

    function link_user_class($dbConnect,$table) {
        echo'
        <form action="actionlink.php" method="post">';
        if ($table == "trainers"){
            dropdown($dbConnect, 'trainers');
            dropdown($dbConnect, 'classes');
            echo'
            <input type="hidden" name="table" value="trainers">
            <input type="submit" value="Link">';        
        } else {
            dropdown($dbConnect, "clients");
            dropdown($dbConnect, "classes");  
            echo'
            <input type="hidden" name="table" value="clients">
            <input type="submit" value="Link">';  
        }
        echo '</form>';
    }

    function dropdown($dbConnect, $table) {
        echo '<select name="' .$table.'">';
            $sql = "SELECT * from $table";
            foreach($dbConnect->query($sql) as $row){
                echo '<option name="'.$table. 'id" value="'.$row['id'].'">'.$row['uname'].'</option>';
            }
        echo '</select>';
    }

    function insertLink($dbConnect, $table, $user, $classes){
        if($table == "trainers"){ 
            $sql = "INSERT INTO trainertoclass (id, trainerid, classid) VALUES (NULL, :uid, :cid)";
        } else {
            $sql = "INSERT INTO clienttoclass(id, clientid, classid) VALUES (NULL, :uid, :cid)";
        }
        $query = $dbConnect->prepare($sql);
        $query->bindParam(":uid", $user);
        $query->bindParam(":cid", $classes);
        $result = $query->execute();
        return $result;
    }

    function view_link($dbConnect, $table) {
        echo '<div class="ctaBox">';
        if($table == "trainers") {
            echo'<h4>Trainer linked to class</h4><hr><br>';
            $sqltable = 'trainertoclass';
            $sql = "SELECT DISTINCT * FROM $sqltable";
            foreach($dbConnect->query($sql) as $row){
                $tableid = $row['id'];
                echo $name = returndetail($dbConnect,$row['trainerid'],"trainers");
                echo ' - ';
                echo $class =returndetail($dbConnect,$row['classid'],"classes");
                echo' <a href="removepage.php?itemid='.$tableid.'&table=trainertoclass">Remove</a><br>';
            }
        } else {
            echo '<h4>Client linked to class</h4><hr><br>';
            $sqltable = 'clienttoclass';
            $sql = "SELECT DISTINCT * FROM $sqltable";
            foreach($dbConnect->query($sql) as $row){
                $tableid = $row['id'];
                echo $name = returndetail($dbConnect,$row['clientid'],"clients");
                echo ' - ';
                echo $class =returndetail($dbConnect,$row['classid'],"classes");
                echo'<a href="removepage.php?itemid='.$tableid.'&table=clienttoclass">Remove</a><br>';
            }
        }
        echo '</div>';
    }

    function returndetail($dbConnect, $id, $table) {
        $sql = "SELECT * FROM $table";
        foreach($dbConnect->query($sql) as $row){
            if($id == $row['id']){
                return $row['uname'];
            }
        }
    }

    function listClasses($dbConnect, $userid, $table){
        echo '<div class="ctaBox">';
        if($table == "trainers"){ 
            $sqltable = "trainertoclass";
        } else{
            $sqltable = "clienttoclass";
        }
        $sql = "SELECT * FROM $sqltable";
        foreach($dbConnect->query($sql) as $row){
            if($table == "trainers"){
                $useridfromtable = $row['trainerid'];
            } else {
                $useridfromtable = $row['clientid'];
            }
            if ($userid == $useridfromtable){
                $id = $row['classid'];
                $result = returndetail($dbConnect, $id, "classes");
                echo ucfirst($result).'<br>';
            }
        }
        echo '</div>';
    }

    function listClients($dbConnect, $userid, $table) {
        $sqltable = "trainertoclass";
        $sql = "SELECT * FROM $sqltable";
        foreach($dbConnect->query($sql) as $row) {
            if($userid == $row['trainerid']){
                $id = $row['classid'];
                $result = returndetail($dbConnect, $id, "classes");
                echo '<h4>'. ucfirst($result).'</h4>';
                listClientsByClass($dbConnect, $id, "clienttoclass");
                echo'<br>';
            }
        }
        
    } 

    function listClientsByClass($dbConnect, $id, $table){
        $sql = "SELECT * FROM $table";
        foreach($dbConnect->query($sql) as $row){
            if($id == $row['classid']){
                $clientid = $row['clientid'];
                $result = returndetail($dbConnect, $clientid, "clients");
                echo ucfirst($result);
                echo '<br>';
            }
        }
    }

    function removeitem($dbConnect, $itemid, $table) {
        $sql= "DELETE FROM $table WHERE id = :id";
        $query = $dbConnect->prepare($sql);
        $query->bindParam(":id", $itemid);
        $query->execute();
    }

    function removefromlinks($dbConnect, $itemid, $table){
        echo $itemid.$table;
        if($table == "trainers"){
            $sqltable = "trainertoclass";
        } else {
            $sqltable = "clienttoclass";
        }
        $sql = "SELECT * FROM $sqltable";
        echo $sql;
        foreach($dbConnect->query($sql) as $row) {
            if($table == "trainers"){
                $useridfromtable = $row['trainerid'];
            } else {
                $useridfromtable = $row['clientid'];
            } 
            if($itemid == $useridfromtable) {
                $rowid = $row['id'];
                removeitem($dbConnect, $rowid, $sqltable);
            }
        }
    }

    function update($dbConnect,$userid,$newpassword,$table){
        $sql ="UPDATE $table set password = :pw WHERE id = :postid";
        $query = $dbConnect -> prepare($sql);
        $query->bindValue(':pw',$newpassword);
        $query->bindValue(':postid',$userid);
        $query->execute();
    }

    function insertEx($dbConnect,$rid,$excercise,$equipment,$sets,$reps){
        $sql ="INSERT INTO exercise (id, rid, name, equipment, sets, reps) VALUES (NULL,:ri,:na,:eq,:se,:re)";
        $query = $dbConnect->prepare($sql);
        $query->bindParam(":ri", $rid);
        $query->bindParam(":na", $excercise);
        $query->bindParam(":eq", $equipment);
        $query->bindParam(":se", $sets);
        $query->bindParam(":re", $reps);
        $result = $query->execute();
    }


    function insertRoutineName($dbConnect,$rname){
        $sql ="INSERT INTO  routinename(id, uname) VALUES (NULL, :na)";
        $query = $dbConnect->prepare($sql);
        $query->bindParam(":na", $rname);
        $result = $query->execute();
        $lastid = $dbConnect->lastInsertId();
        return $lastid;
    }

    function link_user_routine($dbConnect,$table) {
        echo'
        <form action="routinelink.php" method="post">';
        if ($table == "clients"){
            dropdown1($dbConnect, "clients");
            dropdown1($dbConnect, 'routinename');
            echo'
            <input type="hidden" name="table" value="clients">
            <input type="submit" value="Link">';       
        echo '</form>';
    }
}

    function dropdown1($dbConnect, $table) {
        echo '<select name="' .$table.'">';
            $sql = "SELECT * from $table";
            foreach($dbConnect->query($sql) as $row){
                echo '<option value="'.$row['id'].'">'.$row['uname'].'</option>';
            }
        echo '</select>';
    }

    function view_link2($dbConnect, $table) {
        echo '<div class="ctaBox">';
        if($table == "clients") {
            echo'<h4>Client linked to routine</h4><hr><br>';
            $sqltable = 'clientroutine';
            $sql = "SELECT DISTINCT * FROM $sqltable";
            foreach($dbConnect->query($sql) as $row){
                $tableid = $row['id'];
                echo $name = returndetail($dbConnect,$row['clientid'],"clients");
                echo ' - ';
                echo $class =returndetail($dbConnect,$row['rid'],"routinename");
                echo' <a href="removepage.php?itemid='.$tableid.'&table=clientroutine">Remove</a>';
                echo '<a href="updateroutine.php?itemid='.$tableid.'&table=clientroutine">Update</a>';
                echo '<br>';
            }
        } 
        echo '</div>';
    }

    function insertLinkRoutine($dbConnect, $table, $user, $rid) { 
            $sql = "INSERT INTO clientroutine (id, clientid, rid ) VALUES (NULL, :uid, :roid)";
        $query = $dbConnect->prepare($sql);
        $query->bindParam(":uid", $user);
        $query->bindParam(":roid", $rid);
        
    
        $result = $query->execute();
        return $result;

    }

    function listRoutine($dbConnect, $userid) {
        echo '<div class="ctaBox">';
        $sqltable = "clientroutine";

        $sql = " SELECT * FROM $sqltable WHERE clientid = $userid";
        foreach ($dbConnect->query($sql) as $row) {
            $rid = $row['rid'];

            $sqlRoutinename = "SELECT uname FROM routinename WHERE id = $rid";
            foreach ($dbConnect->query($sqlRoutinename) as $routineNameRow){
                $routinename = $routineNameRow['uname'];
                echo 'Routine: ' . ucfirst($routinename) . '<br>';

            $sqlExercises = "SELECT * FROM exercise WHERE rid = $rid ";
            echo 'Exercises: <br>';
            foreach ($dbConnect->query($sqlExercises) as $exerciseRow){
                echo 'Name: ' . ucfirst($exerciseRow['name']) . '<br>';
                echo ' Equipment
                :
                 ' . ucfirst($exerciseRow['equipment']) . '<br>';
                echo ' Sets: ' . ucfirst($exerciseRow['sets']) . '<br>';
                echo ' Reps: ' . ucfirst($exerciseRow['reps']) . '<br>';
                echo '<hr>';
            }
            echo '<br>';
            }
        }
        echo '</div>';
    }


    function listRoutineEdit($dbConnect, $routineid) {
        echo '<div class="ctaBox">';
        $sql = "SELECT * FROM clientroutine WHERE id = $routineid";
        foreach ($dbConnect->query($sql) as $row) {
            $rid = $row['rid'];
            $sqlExercise = "SELECT * FROM exercise WHERE rid = $rid";
            foreach ($dbConnect->query($sqlExercise) as $row2) {
                $sqlRoutinename = "SELECT uname FROM routinename WHERE id = $rid";
                foreach ($dbConnect->query($sqlRoutinename) as $row3) {
            echo '
            <h2>Update Routine Exercise</h2>
            <form action="actionupdaterou.php" method="post">
                <label for="rName">Routine Name</label>
                <input type="text" name="rName" value="'.$row3['uname']. '">
                <input type="hidden" name="rId" value="'.$rid.'">
                <br><br>
                <label for="eName">Exercise Name</label>
                <input type="text" name="eName" value="'.$row2['name']. '"><br>
                <label for="eEquip">Equpiment Description</label>
                <input type="text" name="eEquip" value="'.$row2['equipment'].'"><br>
                <label for="eSets">Sets</label>
                <input type="text" name="eSets" value="'.$row2['sets'].'"><br>
                <label for="eReps">Reps</label>
                <input type="text" name="eReps" value="'.$row2['reps'].'"><br>
                <input type="hidden" name="eId" value="'.$row2['id']. '">
                <input type="hidden" name="routineid" value="'.$routineid.'">
                <input type="submit" value="Update">
                </form>
                <hr>';
                }
            }
        }
        
            echo '</div>';
        }

    function updateRoutine($dbConnect, $field, $detail, $id, $table){
        $sql ="UPDATE $table SET $field = :detail WHERE id = :id";
        $query = $dbConnect -> prepare($sql);
        $query->bindValue(':detail',$detail);
        $query->bindValue(':id',$id);
        $query->execute();
    }

    function viewRoutine($dbConnect, $table) {
        echo '
        <div class="ctaBox">
        <h3>' .ucfirst($table).'</h3><br>';
        $sql = "SELECT * from $table";
        foreach ($dbConnect->query($sql) as $row)
        { 
            $itemid=$row['id'];
            echo $row['uname'];
            
            echo '<br>';
        }
        echo '</div>';
    }

    

    ?>