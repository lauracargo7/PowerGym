<?php
    include_once('../functions/functions.php');
    error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About us</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="header"><h1>About us</h1></div>
    <?php display_Navigation('content');
     ?>


    <div class="aboutus">

        <img src="../images/logo-pg.png"></p>
        <p>Welcome to PowerGym, your premier fitness destination located in the heart of Gold Coast, Australia. Established two years ago, we are dedicated to providing a motivating and supportive environment where you can achieve your fitness goals.<br><br>
        At PowerGym, we pride ourselves on offering state-of-the-art equipment, a wide range of dynamic classes, and expert personal trainers. Whether you're looking to build strength, increase endurance, or simply maintain a healthy lifestyle, our team is here to guide and support you every step of the way.</p><br>

        <div class="p4">Join our community and discover the power of your potential at PowerGym!</div>
    
    </div>
    <div class="footer">
    <div></div>
        <div class="links">
        <a href="about.php"> About Us </a><br>
        <a href="about.php"> Our policy </a><br>
        <a href="index.php"> Log in </a><br>
        </div>

        <div class="media-buttons">
        <a href="#" class="tiktok-button"></a>
        <a href="#" class="insta-button"></a>
        </div>
        <div></div>
    </div>

</body>
</html>