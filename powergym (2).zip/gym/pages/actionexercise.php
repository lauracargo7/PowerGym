<?php
    session_start();
    include_once('../functions/functions.php');
    $dbConnect = dbLink();
    if($dbConnect){
        echo '<!-- Connection established -->';
    }
    
    
    print_r($_POST);    
    $excercise = $_POST['excercise'];
    $equipment = $_POST['equipment'];
    $sets = $_POST['sets'];
    $reps = $_POST['reps'];
    $rid = $_POST['rid'];
    $result = insertEx($dbConnect,$rid,$excercise,$equipment,$sets,$reps);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerGym</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body onload="bounce()">
    <script>
        function bounce(){
            window.location.href= 'addexercise.php';
        }
   </script>
</body>
</html>