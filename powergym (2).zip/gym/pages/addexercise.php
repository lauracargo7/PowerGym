<?php
    session_start();
    include_once('../functions/functions.php');
    $dbConnect = dbLink();
    if($dbConnect){
    echo '<!-- Connection established -->';
}
print_r($_POST);
$routinename = $_GET['routinename'];
if($routinename != NULL){
    $_SESSION['rid'] = insertRoutineName($dbConnect,$routinename);
}




/*
$clients = [];
$sql = "SELECT id, uname FROM clients";
foreach ($dbConnect->query($sql) as $row) {
    $clients[] = $row;
}
*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerGym</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="header" ><h1>Welcome to PowerGym!<h1> 
    </div>

    <div class="nav">
        <?php display_Navigation('notindex'); ?>
    </div>

        <div class="cta">
            <div class="content">
            <?php  if ($_SESSION['validate'] == 'validated') {
                    echo '<h2> Add excercises </h2>
                    <form action="actionexercise.php" method="post">';
                    echo '<input type="hidden" name="rid" value="'.$_SESSION['rid'].'">';

                    echo'<input type="text" name="excercise" placeholder="Enter the excercise"><br>
                        <input type="text" name="equipment" placeholder="Enter the equipment"><br>
                        <input type="text" name="sets" placeholder="Enter number of sets"><br>
                        <input type="text" name="reps" placeholder="Enter number of reps"><br>
                        <input type="submit" value="Add excercises">
                    </form>
                    
                    ';
                    } else {
                    echo 'Not Valid, click Home and try again';
                    }

                    ?>
             </div>   
        </div>    
    
        <div class="footer">
            <div></div>
            <div class="links">
                <a href="#"> About Us </a><br>
                <a href="#"> Our policy </a><br>
                <a href="#"> Log in </a><br>
            </div>
            
            <div class="media-buttons">
                <a href="#" class="tiktok-button"></a>
                <a href="#" class="insta-button"></a>
            </div>
            <div></div>
        </div>

</body>
</html>

