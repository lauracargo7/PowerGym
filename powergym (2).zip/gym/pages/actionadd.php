<?php
session_start();
include_once('../functions/functions.php');
$dbConnect = dbLink();
if($dbConnect){
    echo '<!-- Connection established -->';
}

print_r($_POST);
$uname = $_POST['uname'];
$password = $_POST['password'];
$position = $_POST['position'];

$ciphering = "AES-128-CTR";
$iv_length = openssl_cipher_iv_length($ciphering);
$options = 0;
$encryption_iv = "1234567891011121";

$encryption_key = $uname;
$encrypted_password = openssl_encrypt($password, $ciphering, $encryption_key, $options,
$encryption_iv);

$result = insertuser($dbConnect, $uname, $encrypted_password, $position);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerGym</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body onload="bounce()">
    <script>
        function bounce(){
            window.location.href= 'adduser.php';
        }
    </script>
    
    <div class="footer">
        <div></div>
        <div class="links">
                <a href="#"> About Us </a><br>
                <a href="#"> Our policy </a><br>
                <a href="#"> Log in </a><br>
        </div>
            
        <div class="media-buttons">
                <a href="#" class="tiktok-button"></a>
                <a href="#" class="insta-button"></a>
        </div>
        <div></div>
    </div>

</body>
</html>


