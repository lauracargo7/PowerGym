<?php
    include_once('functions/functions.php');
?>
<?php
    $uname = $_POST['uname'];
    $pwd = $_POST['pwd'];
    $n = FALSE;
    $p = FALSE;

    // Username: username
    // Pasword: p123456

        if($uname == NULL || $pwd == NULL){
            $body = '<body onload="bounce()">';
        } if (strtolower($uname) != 'username'){
            $body = '<body onload="bounce()">';
            $n = FALSE;
        }else {
            $n = TRUE;
        } if (strtolower($pwd) != 'p123456'){
            $body = '<body onload="bounce()">';
            $p = FALSE;
        } else {
            $p = TRUE;
        } if (($n == $p) && ($n == TRUE)){
            $body ='<body>';
        } else {
            $body = '<body onload="bounce()">';
        }

        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerGym</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<?php echo $body; ?>
    <a href="index.php">[ Return to home ]</a>

    <script>
        function bounce(){
           window.location.href= 'index.php' ;
        }
    </script>
    
    <div class="header"><h1>Welcome again!</h1></div>
        
        <div class="forclients">
            <div class="yourinfo">
                <div class="p4">Days Attended:</div>
                <div class="p1"><p>15 days this month</p><br></div>
                <div class="p4">Days Remaining in Subscription:</div>
                <div class="p1"><p>45 days</p><br></div>
                <div class="p4">Personal Trainer</div>
                <div class="p1"><p>Alex Johnson</p><br></div>
            </div>
       
        
        </div>


    <div class="footer">
    <div></div>
        <div class="links">
        <a href="#"> About Us </a><br>
        <a href="#"> Our policy </a><br>
        <a href="#"> Log in </a><br>
        </div>

        <div class="media-buttons">
        <a href="#" class="tiktok-button"></a>
        <a href="#" class="insta-button"></a>
        </div>
        <div></div>
</div>
    
</body>
</html>
