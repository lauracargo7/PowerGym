<?php
    session_start();
    include_once('../functions/functions.php');
    $dbConnect = dbLink();
    if($dbConnect){
        echo '<!-- Connection established -->';
}


$ciphering = "AES-128-CTR";
$iv_length = openssl_cipher_iv_length($ciphering);
$options = 0;
$encryption_iv = "1234567891011121";

if($_SESSION['validate'] == NULL){
    $uname = $_POST['uname'];
    $pwd = $_POST['pwd'];
    $encryption_key = $uname;
    $encrypted_password =openssl_encrypt($pwd,$ciphering,$encryption_key, $options,
    $encryption_iv);
    $position = $_POST['position'];
    $validate = validateUser($dbConnect, $uname, $encrypted_password, $position);
} else{
    if($_SESSION['validate'] != 'validated'){
        if($_SESSION['uname'] != NULL) {
            $uname = $_SESSION['uname'];
            $pwd =$_SESSION['password'];
            $position = $_SESSION['position'];
            if($_SESSION['name'] == 'admin'){
                $position = 'trainer';
        }
        } else {
            $uname = $_POST['uname' ];
            $pwd =$_POST['pwd'];
            $position = $_POST['position'];
            $encryption_key = $uname;
            $encrypted_password = openssl_encrypt($pwd,$ciphering, $encryption_key,
            $options, $encryption_iv);
        }
        $validation = validateUser($dbConnect, $username, $encrypted_password,$position);
    }
}

//ShowMem();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerGym</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="header"><h1>Welcome to PowerGym!<h1></div>

    <div class="nav">
        <?php display_Navigation('not-index'); ?>
    </div>

    <div class="cta-db">
            <div class="content">
            <?php 
                if ($_SESSION['validate'] == 'validated') {
                    //Do something once validated
                    $uname = ucfirst($_SESSION['uname']);
                    echo 'Welcome ' .$uname. '<br><hr>';
                    switch($_SESSION['position']) {
                        case 'admin': 
                            echo '
                            <a href="adduser.php"> Add a new user </a><br>
                            <a href="addclass.php"> Add a new class </a><br>
                            ';
                            viewItem($dbConnect, "trainers");
                            viewItem($dbConnect, "clients");
                            viewItem($dbConnect, "classes");
                            echo '<div class="clear"></div>';
                            echo '<hr><h3>Link Classes</h3>';
                            echo '<br><h4>Trainers to class</h4>';
                            link_user_class($dbConnect,"trainers");
                            echo '<br><h4>Client to class</h4><hr>';
                            link_user_class($dbConnect,"clients");
                            view_link($dbConnect,'trainers');
                            view_link($dbConnect,'clients');
                            echo '<div class="clear"></div>';
                            echo'<br><hr><h3>Add Routine</h3>';
                            echo'<a href="addroutine.php">Add a New Routine</a><br>';
                            echo '<br><h4>Link client to routine</h4><hr>';
                            link_user_routine($dbConnect,"clients");
                            view_link2($dbConnect,'clients');
                        break;
                        case 'trainers': 
                            echo '<br><h3>Class list</h3>';
                            echo '<br>';
                            listClasses($dbConnect, $_SESSION['userid'],'trainers');
                            echo '<br><h3>Clients per Class list </h3>';
                            echo '<br>';
                            listClients($dbConnect, $_SESSION['userid'],'trainers');
                            echo'<br><h3>Add Routine</h3>';
                            echo'<a href="addroutine.php">Add a New Routine</a>';
                            echo '<h4>Link client to routine</h4><hr>';
                            link_user_routine($dbConnect,"clients");
                            view_link2($dbConnect,'clients');
                            echo '<h4>Routines</h4><hr>';
                            viewRoutine($dbConnect, "routinename");
                        break;
                        default:
                            echo '<br><h3>Class list</h3>';
                            echo '<br>';
                                listClasses($dbConnect, $_SESSION['userid'], "clients");
                                echo '<br>';
                            echo '<br><h3>Routine:</h3>';
                                listRoutine($dbConnect, $_SESSION['userid']);
                            echo'<br>'; 
                        break;
                    }
                    } else {
                    echo 'Not Valid, click Home and try again';
                    }
                    ?>
             </div>   
             </div>   
    
        <div class="footer">
            <div></div>
            <div class="links">
                <a href="#"> About Us </a><br>
                <a href="#"> Our policy </a><br>
                <a href="#"> Log in </a><br>
            </div>
            
            <div class="media-buttons">
                <a href="#" class="tiktok-button"></a>
                <a href="#" class="insta-button"></a>
            </div>
            <div></div>
        </div>

</body>
</html>


