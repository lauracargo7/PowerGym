<?php
    session_start();
    include_once('../functions/functions.php');
    $dbConnect = dbLink();
    if($dbConnect){
    echo '<!-- Connection established -->';
    }

    $routineid = $_GET['itemid'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerGym</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="header" ><h1>Welcome to PowerGym!<h1>
        
    </div>

        <?php display_Navigation('not-index');
        ?>

        <div class="cta">
            <div class="content">
                <?php
                if($_SESSION['validate'] == 'validated'){
                    listRoutineEdit($dbConnect, $routineid);
                } else {
                echo 'Not Valid, click Home and try again';
                }
                ?></div>
        </div>

        <div class="footer">
            <div></div>
            <div class="links">
                <a href="#"> About Us </a><br>
                <a href="#"> Our policy </a><br>
                <a href="#"> Log in </a><br>
            </div>
            
            <div class="media-buttons">
                <a href="#" class="tiktok-button"></a>
                <a href="#" class="insta-button"></a>
            </div>
            <div></div>
        </div>

</body>
</html>