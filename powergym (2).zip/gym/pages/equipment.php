<?php
    include_once('../functions/functions.php');
    error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipment Section</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="header"><h1>Equipment Section</h1></div>
    <?php display_Navigation('content');
     ?>

    <div class="info-equipment">
        <p>At PowerGym, we offer a wide range of state-of-the-art equipment designed to optimize your workout. From advanced cardio machines to free weights and strength stations, you'll find everything you need to take your performance to the next level.<p><br>

        <div class="categories">
            <div class="weighandbars">
                <div class="p2">Weights & Bars</div>
            </div>
            <img src="../images/weightbars.jpg" style=" width: 10em" alt="bars">
            <div class="strengthmachines">
                <div class="p2">Strength Machines</div>
                    <p>Benches, bars and racks</p>
                </div>
            <img src="../images/bench.jpg" style=" width: 10em" alt="bench">
            <div class="conditioning">
                <div class="p2">Conditioning</div>
                <p>Body Weigth and conditioning</p>
            </div>
            <img src="../images/conditioning.jpg" style=" width: 10em" alt="conditionging">
            <div class="cardio">
                <div class="p2">Cardio</div>
                <p>Exercise bikes, treadmills, elliptical cross trainers, rowing machines, ski trainers.</p>
            </div>
            <img src="../images/cardio.jpg" style=" width: 10em" alt="cardio">
        </div>    


    </div>


    <div class="footer">
    <div></div>
        <div class="links">
        <a href="about.php"> About Us </a><br>
        <a href="about.php"> Our policy </a><br>
        <a href="index.php"> Log in </a><br>
        </div>

        <div class="media-buttons">
        <a href="#" class="tiktok-button"></a>
        <a href="#" class="insta-button"></a>
        </div>
        <div></div>
    </div>

</body>
<html>