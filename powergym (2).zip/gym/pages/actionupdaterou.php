<?php
    session_start();
    include_once('../functions/functions.php');
    $dbConnect = dbLink();
    if($dbConnect){
        echo '<!-- Connection established -->';
    }

    $rName = $_POST['rName'];
    $rId = $_POST['rId'];
    
    $eName = $_POST['eName'];
    $eEquip =$_POST['eEquip'];
    $eSets = $_POST['eSets'];
    $eReps = $_POST['eReps'];
    $eId = $_POST['eId'];
    //echo $rName.$rId.$eName.$eEquip.$eSets.$eReps.$eId;
    updateRoutine($dbConnect, 'uname', $rName, $rId, 'routinename');
    updateRoutine($dbConnect, 'name', $eName, $eId, 'exercise');
    updateRoutine($dbConnect, 'equipment', $eEquip, $eId, 'exercise');
    updateRoutine($dbConnect, 'sets', $eSets, $eId, 'exercise');
    updateRoutine($dbConnect, 'reps', $eReps, $eId, 'exercise');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerGym</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body onload="bounce()">
    <script>
        function bounce(){
            window.location.href= 'dashboard.php';
        }
    </script>
    
    <div class="footer">
        <div></div>
        <div class="links">
                <a href="#"> About Us </a><br>
                <a href="#"> Our policy </a><br>
                <a href="#"> Log in </a><br>
        </div>
            
        <div class="media-buttons">
                <a href="#" class="tiktok-button"></a>
                <a href="#" class="insta-button"></a>
        </div>
        <div></div>
    </div>

</body>
</html>