<?php
    session_start();
    include_once('../functions/functions.php');
    $dbConnect = dbLink();
    if($dbConnect){
        echo '<!-- Connection established -->';
    }
    $classes =$_POST['classname'];

    $result = insertClass($dbConnect, $classes);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerGym</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body onload="bounce()">
    <script>
        function bounce(){
            window.location.href= 'addclass.php';
        }
    </script>
    
    <div class="footer">
        <div></div>
        <div class="links">
                <a href="#"> About Us </a><br>
                <a href="#"> Our policy </a><br>
                <a href="#"> Log in </a><br>
        </div>
            
        <div class="media-buttons">
                <a href="#" class="tiktok-button"></a>
                <a href="#" class="insta-button"></a>
        </div>
        <div></div>
    </div>

</body>
</html>