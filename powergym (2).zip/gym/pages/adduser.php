<?php
    session_start();
    include_once('../functions/functions.php');
    $dbConnect = dbLink();
    if($dbConnect){
    echo '<!-- Connection established -->';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerGym</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="header" ><h1>Welcome to PowerGym!<h1> 
    </div>

    <div class="nav">
        <?php display_Navigation('notindex'); ?>
    </div>

        <div class="cta">
            <div class="content">
            <?php 
                if ($_SESSION['validate'] == 'validated') {
                    //Do something once validated
                    echo ' 
                    <h2> Add user </h2>
                    <form action="actionadd.php" method="post">
                        <input type="text" name="uname" placeholder="Enter name"><br>
                        <input type="password" name="password" placeholder="Enter password"><br>
                        <select name="position">
                            <option value="clients">Client</option>
                            <option value="trainers">Trainer</option>
                        </select>
                        <input type="submit" value="Add User">
                    </form>
                    ';
                    } else {
                    //Get the user to try to login again.
                    echo 'Not Valid, click Home and try again';
                    }
                    ?>
             </div>   
        </div>    
    
        <div class="footer">
            <div></div>
            <div class="links">
                <a href="#"> About Us </a><br>
                <a href="#"> Our policy </a><br>
                <a href="#"> Log in </a><br>
            </div>
            
            <div class="media-buttons">
                <a href="#" class="tiktok-button"></a>
                <a href="#" class="insta-button"></a>
            </div>
            <div></div>
        </div>

</body>
</html>


