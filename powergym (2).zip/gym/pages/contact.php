<?php
    include_once('../functions/functions.php');
    error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="header"><h1>Contact</h1></div>
    <?php display_Navigation('content');
     ?>
    <div class="contactus">
        <p>We'd love to hear from you! Reach out to us for any inquiries or to book a session.</p><br>
            
        <div class="infocontact">
        <p>
            Address: <br>
            PowerGym<br>
            123 Fitness St,<br>
            Gold Coast, QLD 4217<br>
            Australia<br><br>
            Phone:<br>
            +61 7 1234 5678<br><br>
            Email:<br>
            info@powergym.com.au<br><br>
            Opening Hours:<br>
            Monday to Friday: 6:00 AM - 9:00 PM<br>
            Saturday: 7:00 AM - 6:00 PM<br>
            Sunday: 8:00 AM - 4:00 PM<br>
        </p>

           <div class="imgcontact"> <img src="../images/contact.jpeg"></p></div>
        </div>
    </div>   

    


    </div>
    <div class="footer">
    <div></div>
        <a href="about.php"> About Us </a><br>
        <a href="about.php"> Our policy </a><br>
        <a href="index.php"> Log in </a><br>
        </div>

        <div class="media-buttons">
        <a href="#" class="tiktok-button"></a>
        <a href="#" class="insta-button"></a>
        </div>
        <div></div>
    </div>

</body>
<html>