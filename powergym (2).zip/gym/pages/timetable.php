<?php
    include_once('../functions/functions.php');
    error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF -8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timetable</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="header"><h1>Timetable</h1></div>
    <?php display_Navigation('content');
     ?>


    <div class="info-timetable">
        <div class="intro-timetable"><p>Explore our diverse gym classes, schedule personal training sessions, and easily book your favorite trainers. At PowerGym, we provide the tools and expertise to help you achieve your fitness goals efficiently and effectively.</p><br></div>

        <div class="classes">
            <div class="gymclasses">
                <div class="p2">Various Gym Classes</div>
                <p> Discover our range of classes designed to fit your schedule and fitness goals.</p>
                <img src="../images/gymclasses.png" style=" width: 30vw" alt="gymclasses"><br>
            </div>
            <div class="personaltraining">
                <div class="p2"><br>Personal Training</div>
                <p>Achieve your fitness goals with our expert personal trainers. Check their specialties and availability below.</p>
                <img src="../images/personaltraining.png" style=" width: 16em" alt="personaltraining"><br>
            </div>
            <div class="bookintrainers">
                <div class="p2"><br>Booking Sheet for Trainers</div>
                <p>Schedule your personal training sessions easily. Download our booking sheet to reserve your spot with your preferred trainer.</p>
                <br><a href="../book-a-classs.docx" > Download here </a><br>

            </div>
        </div>
    </div>

    <div class="footer">
    <div></div>
        <div class="links">
        <a href="about.php"> About Us </a><br>
        <a href="about.php"> Our policy </a><br>
        <a href="index.php"> Log in </a><br>
        </div>

        <div class="media-buttons">
        <a href="#" class="tiktok-button"></a>
        <a href="#" class="insta-button"></a>
        </div>
        <div></div>
    </div>

</body>
<html>